from django.contrib import admin
from .models import statuscategory
from .models import statusdescription



admin.site.register(statuscategory)
admin.site.register(statusdescription)


